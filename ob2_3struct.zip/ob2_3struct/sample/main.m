//
//  main.m
//  sample
//
//  Created by Angela on 2020-04-05.
//  Copyright © 2020 angela. All rights reserved.
//

#import <Foundation/Foundation.h>

struct time {
    int day;
    int month;
    int year;
    int hour;
    int minutes;
    int seconds;
};

void timegreet (struct time mytcopy){
    printf("The day is %d/%d/%d, the time is %02d:%02d:%02d\n", mytcopy.month,mytcopy.day,mytcopy.year,mytcopy.hour,mytcopy.minutes,mytcopy.seconds);
}

int main(int argc, const char * argv[]) {
    
    struct time mytime;
    
    mytime.month = 6;
    mytime.day = 29;
    mytime.year = 2007;
    mytime.hour = 16;
    mytime.minutes = 30;
    mytime.seconds = 00;
    
    timegreet(mytime);
    
    return 0;
}



